import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.*;

public class Tester implements CollectionTest
{
    private LinkedList<Person> linkedList;//Defines a linked list of class Person
    private ArrayList<Person> arrayList;//Defines an array list of class Person
    private HashMap<Integer,Person> hashMap;//Defines a hashmap of class Person
    public int size;//A size variable for setting the size of the collections

    public void setSize(int size)
    {
        this.size = size;//Sets the size of the collection to the size parameter
    }

    public void runTest(CollectionType type, TestType test, int iterations)//Parameters for the type of test performed, the collection the test is performed on and the iterations the tests will be performed
    {
       switch(test)//The beginning of a switch case for the type of test being performed
        {
            case ADD://The switch case for the add operation
                for(int i = 0; i<iterations; i++)//A for loop that runs the test to the amount of iterations
                {
                    switch(type)//A switch case for the type of collection the test is being ran on
                    {
                        case LINKED_LIST://The linked list case
                        linkedList = new LinkedList<Person>();//Creates an instance of a linkedList 
                            for(int x = 0; x<size;x++)//A for loop that runs to the size variable
                            {
                                linkedList.add(new Person("Person" + x, 20));//Creates instances of people and adds them to the linked list
                            }
                            break;//Breaks from the switch case
                        case ARRAY_LIST://The array list case
                        arrayList = new ArrayList<Person>();//Creates an instance of an arrayList
                            for(int x = 0; x<size;x++)//Same as above
                            {
                                arrayList.add(new Person("Person" + x, 20));//Same as above except adding to an array list
                            }
                            break;//Breaks from case
                        case HASH_MAP:
                        hashMap = new HashMap<Integer,Person>();//Creates an instance of hashMap
                            for(int x = 0; x<size;x++)//Same as above
                            {
                                hashMap.put(x, new Person("Person" + x, 20));//Same as above except adding to a hashMap
                            }
                            break;//Breaks from case

                        default:// In case none of the above switches occur the default is to break from the loop
                            break;
                    }
                }
                break;
             

            case INDEX://The index case
                for(int i = 0; i<iterations; i++)//Same as above
                {
                    switch(type)//Same as above
                    {
                        case LINKED_LIST://Linked list case
                        
                        linkedList.get(size/2);//Fecthes the element stored at the midpoint of the linked list
                        break;
                        
                        case ARRAY_LIST://Array list case
                        
                        arrayList.get(size/2);//Same as above except for an array list
                        break;
                        
                        case HASH_MAP://Hash map case
                        
                        Collection<Person> collection = hashMap.values();//Creates a collection of class Person based on the values of hash map
                        Iterator<Person> itr = collection.iterator();//An iterator used to iterate through the collection of hash map values
                        int x = 0;
                        for(Person p : collection)//Iterates through the collection
                        {
                            if(x == size/2)//If the value of x is equivalent to half way through the collection
                            {
                                itr.next();//Returns the current element and moves to next element
                                break;//Since we have returned the element at the half way point we break
                            }
                            else
                            {
                                itr.next();//Iterates through the collection until it reaches the person before size/2
                                x++;//Increment x
                            }
                        }
                            
                        break;

                        default:
                            break;
                    }
                }
                break;
              

            case SEARCH://The search case
            for(int i = 0; i<iterations; i++)//Same as above
                {
                    switch(type)//Same as above
                    {
                        case LINKED_LIST:
                        Person l = linkedList.get(size/2);//Gets the person that is half way through the linked list
                        for(int x = 0; x<size ; x++)//Iterates through the linked list
                        {
                            if(linkedList.get(x).equals(l))//Checks if the name of the person in the linked list matches the name of the person half way through the linked list
                            {
                                break;
                            }
                        }
                        break;

                        case ARRAY_LIST:
                        Person a = arrayList.get(size/2);//Same as above except half way through the array list
                        for(int x = 0; x<size ; x++)//Same as above
                        {
                            if(arrayList.get(x).equals(a))//Same as above except for array list
                            {
                                break;
                            }
                        }
                        break;
                        case HASH_MAP:
                        Person h = hashMap.get(size/2);//Same asabove except for hash map
                        for(int x = 0; x<size ; x++)//Same as above
                        {
                           if(hashMap.get(x).equals(h))//Same as above except for hash map
                           {
                                break;
                           } 
                        }
                        break;

                        default:
                            break;
                    }
                }
                break;
            
            default:
                break;
        }
    }
}